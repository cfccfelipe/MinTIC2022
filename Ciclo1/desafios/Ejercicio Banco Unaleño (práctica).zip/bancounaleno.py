#Entrada
vretirar = int(input("Hola, ¿Cúanto desea retirar?: "))

#Programa multiplos de $10.000
r = vretirar % 10000
if r != 0:
    print("El valor a retirar debe ser multiplo de $10.000 ")
else:
    print("Su valor a retirar es: $" + str(vretirar))
#Programa para reducir la cantidad de billetes
tipo1 = 10000
tipo2 = 20000
tipo3 = 50000
tipo4 = 100000
q = 0
z = 0
y = 0
x = 0

if vretirar < 100000:
    z = vretirar // tipo3
    y = (vretirar - tipo3 * z) // tipo2
    x = (vretirar - tipo2 * y - tipo3 * z) //tipo1
    print(str(q) + " X $100000")
    print(str(z) + " X $50000")
    print(str(y) + " X $20000")
    print(str(x) + " X $10000")  
    if vretirar < 50000:
        y = vretirar // tipo2
        x = (vretirar - tipo2 * y) //tipo1
        print(str(q) + " X $100000")
        print(str(z) + " X $50000")
        print(str(y) + " X $20000")
        print(str(x) + " X $10000")  
        if vretirar < 20000:
            x = vretirar // tipo1
            print(str(q) + " X $100000")
            print(str(z) + " X $50000")
            print(str(y) + " X $20000")
            print(str(x) + " X $10000")  
else:
    q = vretirar // tipo4
    z = (vretirar - tipo4 * q) // tipo3
    y = (vretirar - tipo3 * z - tipo4 * q) // tipo2
    x = (vretirar - tipo2 * y - tipo3 * z - tipo4 * q) // tipo1
    print(str(q) + " X $100000")
    print(str(z) + " X $50000")
    print(str(y) + " X $20000")
    print(str(x) + " X $10000")  