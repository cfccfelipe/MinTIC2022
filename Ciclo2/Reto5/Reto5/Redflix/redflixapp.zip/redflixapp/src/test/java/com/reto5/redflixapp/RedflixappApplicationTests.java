package com.reto5.redflixapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RedflixappApplicationTests {

	@Test
	void contextLoads() {
	}

}
